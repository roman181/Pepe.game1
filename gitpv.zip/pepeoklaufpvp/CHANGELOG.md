# PEPE LANES — Changelog (Pass 1 → Pass 20)

This repo contains the **Pass 20** build (all previous pass improvements included).

- Pass 1: Improvements counter + v1.2 gameplay (combat/elixir/cooldowns/projectiles/base/boss telegraph)
- Pass 2: UI polish + better HUD states
- Pass 3: Toast achievements (no blocking alerts)
- Pass 4: Proper modal menu + restart/reset
- Pass 5: Added Shop hook (every 5 waves)
- Pass 6: Upgrade system (regen/cap/dmg/heal)
- Pass 7: Lane danger meter
- Pass 8: Pause/Resume
- Pass 9: Speed toggle
- Pass 10: New unit: Turret (static ranged DPS)
- Pass 11: Hotkeys (1-4, F, Space)
- Pass 12: New enemies: Runner
- Pass 13: New enemies: Brute
- Pass 14: Scaling pass (enemy hp/dmg/ms)
- Pass 15: Boss scaling adjustments
- Pass 16: Base sustain tuning (small wave heal + upgrade heal)
- Pass 17: Persistence consolidation (pl_save + pl_meta)
- Pass 18: Mobile-first input hardening (pointerdown, preventDefault)
- Pass 19: Visual cleanup + danger bar smoothing
- Pass 20: Balance pass + default tutorial toast

Note: Sprites are placeholders in `assets/atlas.png`. Replace with your own pixel art using the atlas slots.
