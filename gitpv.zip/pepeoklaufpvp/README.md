# 🐸 PEPE Lanes — Pass 20

Single-file HTML5 lane strategy game (no build tools). This ZIP is the **Pass 20** build.

## Run
Open `index.html` in a browser.

## What you get (Pass 20)
- Improvements counter (persistent)
- Elixir economy + cooldown cards
- Real combat + projectiles
- Boss phases + telegraphed slam
- Pause + speed toggle
- Lane danger meter
- Shop every 5 waves + upgrades
- New unit: Turret
- New enemies: Runner, Brute

## Files
- `index.html` — game
- `assets/atlas.png` — placeholder atlas template
- `CHANGELOG.md` — pass list
